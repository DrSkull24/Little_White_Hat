<?php
// Simule un accès en mode "hacker"
if ($_GET['access'] === 'root') {
    echo "<h1>💀 Accès au serveur compromis 💀</h1>";
    echo "<p>Redirection vers /piège/index.html dans 5 secondes...</p>";

    // Redirection après 5 secondes
    header("Refresh: 5; url=/piège/index.html");
} else {
    http_response_code(403);
    die("Accès refusé");
}
?>
